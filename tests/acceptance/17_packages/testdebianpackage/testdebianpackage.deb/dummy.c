#include <stdio.h>

int main(int argc, char ** argv)
{
 
    char * out = "This is a really complex piece of software!\n";
    printf("My program says: %s", out);
    return 0;
}