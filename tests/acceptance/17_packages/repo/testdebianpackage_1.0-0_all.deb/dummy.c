#include <stdio.h>

int main(int argc, char ** argv)
{
 
    char * out = "Debian package version 1.0-1\n";
    printf("My program version is: %s", out);
    return 0;
}